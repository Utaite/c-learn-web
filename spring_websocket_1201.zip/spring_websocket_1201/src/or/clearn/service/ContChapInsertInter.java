package or.clearn.service;

import or.vo.ChapEnrollVO;
import or.vo.ContentEnrollVO;

public interface ContChapInsertInter {
	public void insertAll(ContentEnrollVO ctvo, ChapEnrollVO chvo) throws Exception;
}
