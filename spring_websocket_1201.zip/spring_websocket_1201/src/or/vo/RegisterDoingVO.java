package or.vo;

public class RegisterDoingVO {
	private int cnt_ch_num, cnt_cl_done, finish_date;
	private String cc_name, ct_sub, ch_sub, cl_date;
	private int p_num, ch_num, ct_num, cl_done, percent, v_num;
	public int getV_num() {
		return v_num;
	}
	public void setV_num(int v_num) {
		this.v_num = v_num;
	}
	private String cl_end;
	public String getCl_date() {
		return cl_date;
	}
	public void setCl_date(String cl_date) {
		this.cl_date = cl_date;
	}
	
	public String getCh_sub() {
		return ch_sub;
	}
	public void setCh_sub(String ch_sub) {
		this.ch_sub = ch_sub;
	}
	
	public int getCnt_ch_num() {
		return cnt_ch_num;
	}
	public void setCnt_ch_num(int cnt_ch_num) {
		this.cnt_ch_num = cnt_ch_num;
	}
	public int getCnt_cl_done() {
		return cnt_cl_done;
	}
	public void setCnt_cl_done(int cnt_cl_done) {
		this.cnt_cl_done = cnt_cl_done;
	}
	public int getFinish_date() {
		return finish_date;
	}
	public void setFinish_date(int finish_date) {
		this.finish_date = finish_date;
	}
	public String getCc_name() {
		return cc_name;
	}
	public void setCc_name(String cc_name) {
		this.cc_name = cc_name;
	}
	public String getCt_sub() {
		return ct_sub;
	}
	public void setCt_sub(String ct_sub) {
		this.ct_sub = ct_sub;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getCh_num() {
		return ch_num;
	}
	public void setCh_num(int ch_num) {
		this.ch_num = ch_num;
	}
	public int getCt_num() {
		return ct_num;
	}
	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}
	public int getCl_done() {
		return cl_done;
	}
	public void setCl_done(int cl_done) {
		this.cl_done = cl_done;
	}
	public String getCl_end() {
		return cl_end;
	}
	public void setCl_end(String cl_end) {
		this.cl_end = cl_end;
	}
	public int getPercent() {
		return percent;
	}
	public void setPercent(int percent) {
		this.percent = percent;
	}
	
	
}
