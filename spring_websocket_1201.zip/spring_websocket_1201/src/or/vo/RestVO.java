package or.vo;

public class RestVO {

	private int v_num, v_ctime, v_finish, ch_num;
	private String p_id, p_pw, p_token, before_token, ch_file, p_cresult, p_qresult;

	public String getP_cresult() {
		return p_cresult;
	}

	public void setP_cresult(String p_cresult) {
		this.p_cresult = p_cresult;
	}

	public String getP_qresult() {
		return p_qresult;
	}

	public void setP_qresult(String p_qresult) {
		this.p_qresult = p_qresult;
	}

	public int getV_num() {
		return v_num;
	}

	public void setV_num(int v_num) {
		this.v_num = v_num;
	}

	public int getV_ctime() {
		return v_ctime;
	}

	public void setV_ctime(int v_ctime) {
		this.v_ctime = v_ctime;
	}

	public String getP_id() {
		return p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}

	public String getP_pw() {
		return p_pw;
	}

	public void setP_pw(String p_pw) {
		this.p_pw = p_pw;
	}

	public String getP_token() {
		return p_token;
	}

	public void setP_token(String p_token) {
		this.p_token = p_token;
	}


	public String getCh_file() {
		return ch_file;
	}

	public void setCh_file(String ch_file) {
		this.ch_file = ch_file;
	}

	public String getBefore_token() {
		return before_token;
	}

	public void setBefore_token(String before_token) {
		this.before_token = before_token;
	}

	public int getV_finish() {
		return v_finish;
	}

	public void setV_finish(int v_finish) {
		this.v_finish = v_finish;
	}

	public int getCh_num() {
		return ch_num;
	}

	public void setCh_num(int ch_num) {
		this.ch_num = ch_num;
	}
	

}