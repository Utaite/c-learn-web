package or.vo;

public class QuizVO {

	private int number, v_num;
	private String userAnswerList, quizAnswerList, resultList;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getV_num() {
		return v_num;
	}

	public void setV_num(int v_num) {
		this.v_num = v_num;
	}

	public String getUserAnswerList() {
		return userAnswerList;
	}

	public void setUserAnswerList(String userAnswerList) {
		this.userAnswerList = userAnswerList;
	}

	public String getQuizAnswerList() {
		return quizAnswerList;
	}

	public void setQuizAnswerList(String quizAnswerList) {
		this.quizAnswerList = quizAnswerList;
	}

	public String getResultList() {
		return resultList;
	}

	public void setResultList(String resultList) {
		this.resultList = resultList;
	}

}
