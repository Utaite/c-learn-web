package or.vo;

public class SearchFaqBoardVO {
	private int f_num;
	private String f_sub, f_cont;

	public int getF_num() {
		return f_num;
	}

	public void setF_num(int f_num) {
		this.f_num = f_num;
	}

	public String getF_sub() {
		return f_sub;
	}

	public void setF_sub(String f_sub) {
		this.f_sub = f_sub;
	}

	public String getF_cont() {
		return f_cont;
	}

	public void setF_cont(String f_cont) {
		this.f_cont = f_cont;
	}

	public SearchFaqBoardVO() {
	}

}
