package or.vo;

public class DostarVO {
	private int ct_num, p_num, ct_star;

	public int getP_num() {
		return p_num;
	}

	public void setP_num(int p_num) {
		this.p_num = p_num;
	}

	public int getCt_star() {
		return ct_star;
	}

	public void setCt_star(int ct_star) {
		this.ct_star = ct_star;
	}

	public int getCt_num() {
		return ct_num;
	}

	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}

}
