package or.vo;

public class RegisterDoneVO {
	private int ct_num, cl_dostar, cc_num, p_num, ch_num, cl_done, cnt_ch_num, cnt_cl_done, percent ,ct_starnum, cl_num;
	private float ct_star;
	public int getCl_num() {
		return cl_num;
	}
	public float getCt_star() {
		return ct_star;
	}
	public void setCt_star(float ct_star) {
		this.ct_star = ct_star;
	}
	public void setCl_num(int cl_num) {
		this.cl_num = cl_num;
	}
	private String cc_name, ct_sub, cl_end, cl_end_res;
	public int getCt_num() {
		return ct_num;
	}
	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}
	public int getCl_dostar() {
		return cl_dostar;
	}
	public void setCl_dostar(int cl_dostar) {
		this.cl_dostar = cl_dostar;
	}
	public int getCc_num() {
		return cc_num;
	}
	public void setCc_num(int cc_num) {
		this.cc_num = cc_num;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getCh_num() {
		return ch_num;
	}
	public void setCh_num(int ch_num) {
		this.ch_num = ch_num;
	}
	public int getCl_done() {
		return cl_done;
	}
	public void setCl_done(int cl_done) {
		this.cl_done = cl_done;
	}
	public int getCnt_ch_num() {
		return cnt_ch_num;
	}
	public void setCnt_ch_num(int cnt_ch_num) {
		this.cnt_ch_num = cnt_ch_num;
	}
	public int getCnt_cl_done() {
		return cnt_cl_done;
	}
	public void setCnt_cl_done(int cnt_cl_done) {
		this.cnt_cl_done = cnt_cl_done;
	}
	public int getPercent() {
		return percent;
	}
	public void setPercent(int percent) {
		this.percent = percent;
	}
	public int getCt_starnum() {
		return ct_starnum;
	}
	public void setCt_starnum(int ct_starnum) {
		this.ct_starnum = ct_starnum;
	}
	public String getCc_name() {
		return cc_name;
	}
	public void setCc_name(String cc_name) {
		this.cc_name = cc_name;
	}
	public String getCt_sub() {
		return ct_sub;
	}
	public void setCt_sub(String ct_sub) {
		this.ct_sub = ct_sub;
	}
	public String getCl_end() {
		return cl_end;
	}
	public void setCl_end(String cl_end) {
		this.cl_end = cl_end;
	}
	public String getCl_end_res() {
		return cl_end_res;
	}
	public void setCl_end_res(String cl_end_res) {
		this.cl_end_res = cl_end_res;
	}
	

}