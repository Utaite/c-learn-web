package or.clearn.service;

public interface MomBoardDeleteInter {

	public void deleteAll(int ib_num) throws Exception;
}
