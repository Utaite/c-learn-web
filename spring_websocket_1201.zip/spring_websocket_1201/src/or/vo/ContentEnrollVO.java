package or.vo;

public class ContentEnrollVO {

	int ct_num, cc_num, ct_hit, ct_star, ct_starnum, ct_period;
	String ct_sub, ct_date, ct_detail;
 
	public int getCt_num() {
		return ct_num;  
	}  
       
	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}

	public int getCc_num() {
		return cc_num;
	} 
    
	public void setCc_num(int cc_num) {
		this.cc_num = cc_num;
	}

	public int getCt_hit() {
		return ct_hit;
	}

	public void setCt_hit(int ct_hit) {
		this.ct_hit = ct_hit;
	}

	public int getCt_star() {
		return ct_star;
	}

	public void setCt_star(int ct_star) {
		this.ct_star = ct_star;
	}

	public int getCt_starnum() {
		return ct_starnum;
	}

	public void setCt_starnum(int ct_starnum) {
		this.ct_starnum = ct_starnum;
	}

	public int getCt_period() {
		return ct_period;
	}

	public void setCt_period(int ct_period) {
		this.ct_period = ct_period;
	}

	public String getCt_sub() {
		return ct_sub;
	}

	public void setCt_sub(String ct_sub) {
		this.ct_sub = ct_sub;
	}

	public String getCt_date() {
		return ct_date;
	}

	public void setCt_date(String ct_date) {
		this.ct_date = ct_date;
	}

	public String getCt_detail() {
		return ct_detail;
	}

	public void setCt_detail(String ct_detail) {
		this.ct_detail = ct_detail;
	}
 
	

}
