package or.clearn.service;

import or.vo.DostarVO;

public interface DoStarUpdateInter {
	public void starUpdate(DostarVO vo) throws Exception;
}
