package or.vo;

public class RegisterClassListVO {
	private int ch_num, ch_time, cl_done, ct_num;
	private String ch_sub, cl_date;
	public int getCh_num() {
		return ch_num;
	}
	public void setCh_num(int ch_num) {
		this.ch_num = ch_num;
	}
	public int getCh_time() {
		return ch_time;
	}
	public void setCh_time(int ch_time) {
		this.ch_time = ch_time;
	}
	public int getCl_done() {
		return cl_done;
	}
	public void setCl_done(int cl_done) {
		this.cl_done = cl_done;
	}
	public int getCt_num() {
		return ct_num;
	}
	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}
	public String getCh_sub() {
		return ch_sub;
	}
	public void setCh_sub(String ch_sub) {
		this.ch_sub = ch_sub;
	}
	public String getCl_date() {
		return cl_date;
	}
	public void setCl_date(String cl_date) {
		this.cl_date = cl_date;
	}
	
}
