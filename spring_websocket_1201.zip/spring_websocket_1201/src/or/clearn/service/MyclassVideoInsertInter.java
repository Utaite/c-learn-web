package or.clearn.service;

import or.vo.MyClassVO;
import or.vo.RestVO;

public interface MyclassVideoInsertInter {
	public void insertMyclassVideo(MyClassVO mcvo,RestVO rvo) throws Exception;
}
