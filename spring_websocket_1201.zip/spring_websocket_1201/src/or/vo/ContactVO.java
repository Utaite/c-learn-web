package or.vo;

public class ContactVO {
	private int con_num;
	private String con_name, con_mail, con_phone, con_msg;
	public int getCon_num() {
		return con_num;
	}
	public void setCon_num(int con_num) {
		this.con_num = con_num;
	}
	public String getCon_name() {
		return con_name;
	}
	public void setCon_name(String con_name) {
		this.con_name = con_name;
	}
	public String getCon_mail() {
		return con_mail;
	}
	public void setCon_mail(String con_mail) {
		this.con_mail = con_mail;
	}
	public String getCon_phone() {
		return con_phone;
	}
	public void setCon_phone(String con_phone) {
		this.con_phone = con_phone;
	}
	public String getCon_msg() {
		return con_msg;
	}
	public void setCon_msg(String con_msg) {
		this.con_msg = con_msg;
	}
}
