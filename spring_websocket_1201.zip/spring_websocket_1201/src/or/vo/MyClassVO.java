package or.vo;

public class MyClassVO {

	private int cl_num, p_num, ct_num, ch_num, cl_done, cl_dostar;
	private String cl_date, cl_start, cl_end;
	private int ct_period;

	public int getCt_period() {
		return ct_period;
	}

	public void setCt_period(int ct_period) {
		this.ct_period = ct_period;
	}

	public int getCl_num() {
		return cl_num;
	}

	public void setCl_num(int cl_num) {
		this.cl_num = cl_num;
	}

	public int getP_num() {
		return p_num;
	}

	public void setP_num(int p_num) {
		this.p_num = p_num;
	}

	public int getCt_num() {
		return ct_num;
	}

	public void setCt_num(int ct_num) {
		this.ct_num = ct_num;
	}

	public int getCh_num() {
		return ch_num;
	}

	public void setCh_num(int ch_num) {
		this.ch_num = ch_num;
	}

	public int getCl_done() {
		return cl_done;
	}

	public void setCl_done(int cl_done) {
		this.cl_done = cl_done;
	}

	public String getCl_date() {
		return cl_date;
	}

	public void setCl_date(String cl_date) {
		this.cl_date = cl_date;
	}

	public String getCl_start() {
		return cl_start;
	}

	public void setCl_start(String cl_start) {
		this.cl_start = cl_start;
	}

	public String getCl_end() {
		return cl_end;
	}

	public void setCl_end(String cl_end) {
		this.cl_end = cl_end;
	}

	public int getCl_dostar() {
		return cl_dostar;
	}

	public void setCl_dostar(int cl_dostar) {
		this.cl_dostar = cl_dostar;
	}

}
